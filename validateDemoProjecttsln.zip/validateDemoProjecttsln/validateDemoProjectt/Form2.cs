﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace validateDemoProjectt
{
    public partial class Form2 : Form
    {
        int slnoForUpdateFunction = 0;
        public static string connectionString = @"Data Source=VITHINKANTHRAJ\SQLEXPRESS;Initial Catalog=ICCA2021;Integrated Security=True";  
        public Form2()
        {
            InitializeComponent();
            button3.Visible = false;
        }
        public Form2(int slno)
        {
            InitializeComponent();
            button2.Visible = false;
            loadControlsWithDataToUpdate(slno);
            button3.Visible = true;
            slnoForUpdateFunction = slno;
        }
        public void loadControlsWithDataToUpdate(int slno)
        {
            DataTable dt = new DataTable();
            dt = getStudentDetails();
            DataRow[] dr = dt.Select("Slno = " + slno);
            foreach (DataRow row in dr)
            {
                textBox1.Text = row["name"].ToString();
                richTextBox1.Text = row["address"].ToString();
                textBox2.Text = row["age"].ToString();
                // string ddlValue = Convert.ToString(row["gender"]);
                // ddlDegree.SelectedValue = id;
                string rbtValue = row["Gender"].ToString();
                if (rbtValue.Equals("Male"))
                    radioButton1.Checked = true;
                else if (rbtValue.Equals("FeMale"))
                    radioButton2.Checked = true;
                else if (rbtValue.Equals("Other"))
                    radioButton3.Checked = true;
                else
                    radioButton1.Checked = true;
            }
        }
        public static DataTable getStudentDetails()
        {

            DataTable dt = new DataTable();

            dt.Columns.Add("Slno", typeof(int));
            dt.Columns.Add("NAME", typeof(string));
            dt.Columns.Add("ADDRESS", typeof(string));
            dt.Columns.Add("age", typeof(int));
            dt.Columns.Add("Gender", typeof(string));




            SqlConnection connectionObject = new SqlConnection(connectionString);
            connectionObject.Open();
            String queryToExecute = "SELECT * FROM PERSONS";

            SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
            SqlDataReader sdr = commandObject.ExecuteReader();
            while (sdr.Read())
            {
                DataRow dr = dt.NewRow();
                dr["Slno"] = sdr["Sl_no"];
                dr["Name"] = sdr["Name"];
                dr["ADDRESS"] = sdr["address"];
                dr["AGE"] = (Convert.ToInt32(sdr["Age"]));
                dr["Gender"] = (sdr["Gender"]);
                dt.Rows.Add(dr);
            }
            return dt;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            int result = 0;
            string gender = "0";
            try
            {
                if (validate())
                {
                    SqlConnection connectionObject = new SqlConnection(connectionString);
                    connectionObject.Open();
                    if (radioButton1.Checked)
                    {
                        gender = "male";
                    }
                    if (radioButton2.Checked)
                    {
                        gender = "Female";
                    }
                    if (radioButton3.Checked)
                    {
                        gender = "OTHERS";
                    }

                    string querryToExecute = "INSERT INTO PERSONS VALUES('" + textBox1.Text + "' , '" + richTextBox1.Text + "'," + Convert.ToInt32(textBox2.Text) + ",'" + gender + "')";
                    SqlCommand commandObject = new SqlCommand(querryToExecute, connectionObject);
                    result = commandObject.ExecuteNonQuery();
                }
            }
            catch (Exception exec)
            {
                {
                    MessageBox.Show(exec.ToString(), "Alert");
                }
            }
            finally
            {
                if (result == 1)
                {
                    MessageBox.Show("Data updated successfully", "Information");
                }
            }
        }
        private bool validate()
        {
            bool isValidated = true;
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Enter NAME", "Alert");
                isValidated = false;
            }
            else if (String.IsNullOrEmpty(richTextBox1.Text))
            {
                MessageBox.Show("Enter address", "Alert");
                isValidated = false;

            }
            else if (String.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Enter Age ", "Alert");
                isValidated = false;
            }
            else if (!(radioButton1.Checked || radioButton2.Checked || radioButton3.Checked))
            {
                MessageBox.Show("Select Gender ", "Alert");
                isValidated = false;
            }
            return isValidated;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            richTextBox1.Text = "";
            if (radioButton1.Checked || radioButton2.Checked || radioButton3.Checked)
            {
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int result = 0;
            string rbtValue = "0";

            try
            {


                if (validate())
                {
                    cl̥clsStudent ObjectclsStudent = new cl̥clsStudent();
                    ObjectclsStudent.slno = slnoForUpdateFunction;
                    ObjectclsStudent.name = textBox1.Text;
                    ObjectclsStudent.address = richTextBox1.Text;
                    ObjectclsStudent.age = Convert.ToInt32(textBox2.Text);
                    if (radioButton1.Checked)
                        rbtValue = "male";
                    else if (radioButton2.Checked)
                        rbtValue = "Feamle";
                    else if (radioButton3.Checked)
                        rbtValue = "others";
                    ObjectclsStudent.gender = rbtValue;
                    result = updatePersonDetails(ObjectclsStudent);
                }
            }

            catch (Exception exec)
            {
                {
                    MessageBox.Show(exec.ToString(), "Alert");
                }
            }
            finally
            {
                if (result == 1)
                {
                    MessageBox.Show("Data updated successfully", "Information");
                }
            }

        }

        public static int updatePersonDetails(cl̥clsStudent clsStudentObject)
        {

            SqlConnection connectionObject = new SqlConnection(connectionString);
            connectionObject.Open();
            String queryToExecute = "UPDATE PERSONS SET  NAME = '" + clsStudentObject.name + "', address = '" + clsStudentObject.address + "', age='" + clsStudentObject.age + "', GENDER = '" + clsStudentObject.gender + "' WHERE SL_NO = " + clsStudentObject.slno;
            SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
            int result = commandObject.ExecuteNonQuery();
            connectionObject.Close();
            return result;
        }

    }
}
