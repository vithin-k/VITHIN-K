﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace validateDemoProjectt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Form2 objCreateForm = null;
        Form3 objViewForm = null;
        private void cREATEToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (objCreateForm == null)
            {
                objCreateForm = new Form2();
                objCreateForm.FormClosed += objCreateForm_FormClosed;
                if (objViewForm != null) objViewForm.Close();
                objCreateForm.Show();
            }
            else
            {
                if (objViewForm != null) objViewForm.Close();
                objCreateForm.Activate();
            }
        }

        void objCreateForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            objCreateForm = null;
            //throw new NotImplementedException();
        }
       
        private void vIEWToolStripMenuItem_Click(object sender, EventArgs e)
        {
                        
             if (objViewForm == null)
            {
                objViewForm = new Form3();
                objViewForm.FormClosed += objViewForm_FormClosed;
               if(objCreateForm != null) objCreateForm.Close();
                objViewForm.Show();
            }
            else
            {
                if (objCreateForm != null)  objCreateForm.Close();
                objViewForm.Activate();
            }
        }
        void objViewForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            objViewForm = null;
        } 
    }
}
