﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace validateDemoProjectt
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            doGridLoadingWork();     
            //dataGridView1.Columns["slno"].Visible = false;
            //dataGridView1.Columns(0).visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
        public void doGridLoadingWork()
        {
            SqlConnection connectionObject = new SqlConnection(Form2.connectionString);
            connectionObject.Open();
            String queryToExecute = "select   * from persons";
            SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
            DataTable dt = new DataTable();
            SqlDataAdapter ob = new SqlDataAdapter(commandObject);
            ob.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {

            int rowIndex = dataGridView1.CurrentCell.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[rowIndex];
            int slno = Convert.ToInt32(row.Cells[0].Value);
            string name = (row.Cells[1].Value).ToString();
            var confirmResult = MessageBox.Show("Are you sure to delete " + name + "'s record.?", "Confirm Delete!!", MessageBoxButtons.YesNo);                                    
            if (confirmResult == DialogResult.Yes)
            {
                int result = deletePersonDetails(slno);
                if (result == 1)
                {
                    MessageBox.Show(name + "'s record deleted", "Information");
                    doGridLoadingWork();

                }
                else
                {
                    MessageBox.Show(name + "'s record not deleted", "alert");
                }
            }
            else
            {
                // If 'No', do something here.
            }
        }   
        public int deletePersonDetails(int sl_no)
        {
            int result = 0;
            SqlConnection connectionObject = new SqlConnection(Form2.connectionString);
            connectionObject.Open();
            String queryToExecute = "DELETE FROM PERSONS WHERE SL_NO = " + sl_no;
            SqlCommand commandObject = new SqlCommand(queryToExecute, connectionObject);
            result = commandObject.ExecuteNonQuery();
            connectionObject.Close();
            return result;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView1.CurrentCell.RowIndex;
            DataGridViewRow row = dataGridView1.Rows[rowIndex];
            int slno = Convert.ToInt32(row.Cells[0].Value);
            Form2 objectCreateForm = new Form2(slno);
            objectCreateForm.Show();
            this.Close();
        }
    } 
   
}
